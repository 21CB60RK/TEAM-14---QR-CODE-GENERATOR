from tkinter import *
from tkinter import messagebox
import pyqrcode
import qrcode

ws = Tk()
ws.title("QR Code Generator")
Label(text="QR Code Generator for Employees", bg="black",fg="white", width="300", height="2", font=("bold", 20)).pack()
ws.config(bg='#66CDAA')
ws.geometry("550x500")

def generate_QR():
    if len(user_input.get())!=0 :
        global qr,img
        qr = pyqrcode.create(user_input.get() + "_"+user_input1.get())
        img = BitmapImage(data = qr.xbm(scale=8))
        
        img1 = qrcode.make(user_input.get() + "_"+user_input1.get())
        type(img1) 
        img1.save(f'{user_input1.get()}.png')
        #Label(ws, text='File Saved!', fg='green').pack()
        messagebox.showinfo("Success",'File Saved!')
        
        
    else:
        messagebox.showwarning('warning', 'All Fields are Required!')
    try:
        display_code()
    except:
        pass

def display_code():
    img_lbl.config(image = img)
    output.config(text="QR code of " + user_input.get())



#labels for Em.name and Em.no
Label(ws,text="",bg='#66CDAA').pack()
lbl = Label(
    ws,
    text="Employee Name",
    bg='#66CDAA',
    )
lbl.pack()
user_input = StringVar()
entry = Entry(
    ws,
    width=30,
    textvariable = user_input
    )
entry.pack(padx=10)
Label(ws,text="",bg='#66CDAA').pack()

lb2 = Label(
    ws,
    text="Employee Number",
    bg='#66CDAA'
    )
lb2.pack()

user_input1 = StringVar()
entry1 = Entry(
    ws,
    width=30,
    textvariable = user_input1
    )
entry1.pack(padx=10)
Label(ws,text="",bg='#66CDAA').pack()


button = Button(
    ws,
    text = "GENERATE QR",
    width=15,
    height='2',
    bg='black',
    fg='white',
    command = generate_QR
    )
button.pack(pady=10)

img_lbl = Label(
    ws,
    bg='#66CDAA')
img_lbl.pack()
output = Label(
    ws,
    text="",
    bg='#66CDAA',
    )
output.pack()
 
ws.mainloop()
